# CECS343-Project
Group assignment  where we design and make a warehouse management application
