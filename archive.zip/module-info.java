
module Project {
	//exports project;
	requires json.simple;
	requires java.json;
	requires gson;
}
