//package project;
module Project {
	//exports project;
	requires json.simple;
	requires java.json;
}